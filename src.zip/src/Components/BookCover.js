import React from "react";

export class BookCover extends React.Component
{
    render() {
        return<div>
            <img src = "http://img3m9.ddimg.cn/12/36/1546133799-1_w_1.jpg" alt = "java"/>
        </div>
    }
}