const data = [
    {
        name: "A",
        price: "123",
    }
];