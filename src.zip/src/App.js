import logo from './logo.svg';
import './App.css';
import {BasicRoute} from "./BasicRoute";

function App() {
  return (
      <div>
        <BasicRoute />
      </div>
  );
}
export default App;
