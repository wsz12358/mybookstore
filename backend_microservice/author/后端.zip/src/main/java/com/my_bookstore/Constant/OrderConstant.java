package com.my_bookstore.Constant;

public class OrderConstant {
    public static final String TOTALPRICE = "total_price";
    public static final String ORDERTIME = "ordertime";
    public static final String ORDERSTATE = "orderstate";

    public static final String ORDERID = "id";
    public static final String USERAUTHID = "id";

}
