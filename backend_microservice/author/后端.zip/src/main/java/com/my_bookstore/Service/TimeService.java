package com.my_bookstore.Service;

public interface TimeService {
    void BeginTimer();

    void StopTimer();
}
