package com.my_bookstore.Constant;

public class KafkaConstant {
    public static final String KAFKAORDER = "bookstoreOrder";
}
