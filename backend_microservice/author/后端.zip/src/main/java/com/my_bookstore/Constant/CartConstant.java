package com.my_bookstore.Constant;

public class CartConstant {

    public static final String BOOKID = "book";

    public static final String PURCHASE_NUM = "purchasenum";

    public static final String USERAUTHID = "userauthid";
}
