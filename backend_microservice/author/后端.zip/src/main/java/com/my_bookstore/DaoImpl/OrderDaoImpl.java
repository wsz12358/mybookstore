package com.my_bookstore.DaoImpl;

import com.my_bookstore.Dao.OrderDao;
import com.my_bookstore.Entity.Cart;
import com.my_bookstore.Entity.Order;
import com.my_bookstore.Entity.OrderProduct;
import com.my_bookstore.Entity.UserAuth;
import com.my_bookstore.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public class OrderDaoImpl implements OrderDao {

    @Autowired
    OrderRepository orderRepository;
    @Autowired
    OrderProductRepository orderProductRepository;

    @Autowired
    CartRepository cartRepository;

    @Autowired
    UserAuthRepository userAuthRepository;

    @Autowired
    BookRepository bookRepository;

    @Override
    public List<Order> getOrders()
    {
        return orderRepository.findAll();
    }

    @Override
    @Transactional
    public void setOrder(Order order)
    {
        orderRepository.save(order);
        //int result = 10 / 0;
    }

    @Override
    @Transactional
    public void setOrderProduct(OrderProduct op)
    {
        orderProductRepository.save(op);
        // int result = 10 / 0;
    }
  
    @Override
    public List<Cart> GetCarts()
    {
        return cartRepository.findAll();
    }

    @Override
    public void DeleteCartByUserAuth(Integer id)
    {
        cartRepository.deleteCartsByUserAuth(id);
    }

    @Override
    public void DeleteOrderproduct(Integer id)
    {
        orderProductRepository.deleteOrderProducts(id);
    }

    @Override
    public void DeleteOrder(Integer id)
    {
        orderRepository.deleteOrderById(id);
    }

    @Override
    public Order GetOrder(Integer id)
    {
        return orderRepository.getOrder(id);
    }

    @Override
    public UserAuth GetUserAuth(Integer id){return userAuthRepository.findUserAuthByUserId(id);}

    @Override
    public List<Cart> getCartsByUserAuth(Integer id){return cartRepository.findCartsByUserAuth(id);}

    @Override
    public List<Order> getOrdersByUserAuth(Integer id){return orderRepository.getOrdersByUser(id);}

    @Override
    public void UpdateInventory(Integer num, Integer id) {bookRepository.UpdateInventory(num ,id);}
}
