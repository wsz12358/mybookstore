package com.my_bookstore.Dao;
import com.my_bookstore.Entity.Book;

import java.util.List;

public interface BookDao {
    Book findOne(Integer id);

    List<Book> getBooks();

    void addBook(Book book);

    void deleteBook(Integer id);

    void UpdateBook(String name, String author, String image, String isbn, Integer inventory, Integer id);
}
