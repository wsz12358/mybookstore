package com.my_bookstore.Constant;

public class LoginConstant {
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
    public static final String USERID = "id";
    public static final String EMAIL = "email";
}
