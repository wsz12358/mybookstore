package com.my_bookstore.DaoImpl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.my_bookstore.Dao.BookDao;
import com.my_bookstore.Entity.Book;
import com.my_bookstore.Repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import java.time.Duration;
import java.util.List;
@Repository
public class BookDaoImpl implements BookDao {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private RedisTemplate redisTemplate;
    @Override
    public Book findOne(Integer id){
        String key = String.valueOf(id);
        String json = JSON.toJSONString(redisTemplate.opsForValue().get(key));
        if (!json.equals("null"))
        {
            Book book = JSON.parseObject(json, Book.class);
            System.out.println("get book " + key + " from redis, value is " + json);
            return book;
        }
        Book book = bookRepository.getOne(id);
        redisTemplate.opsForValue().set(key, JSON.toJSON(book), Duration.ofMinutes(30));
        System.out.println("set book " + key + " into redis");
        return book;
    }
    @Override
    public List<Book> getBooks() {
        return bookRepository.getBooks();
    }

    @Override
    public void addBook(Book book)
    {
        bookRepository.save(book);
    }

    @Override
    public void deleteBook(Integer id)
    {
        String key = String.valueOf(id);
        Boolean del = redisTemplate.delete(key);
        System.out.println("delete book " + key + " from redis, result is " + del);
        bookRepository.deleteBookByBookId(id);
    }

    @Override
    public void UpdateBook(String name, String author, String image, String isbn, Integer inventory, Integer id)
    {
        String key = String.valueOf(id);
        bookRepository.UpdateBook(name, author, image, isbn, inventory, id);
        Boolean del = redisTemplate.delete(key);
        System.out.println("delete book " + key + " from redis, result is " + del);
    }

}
