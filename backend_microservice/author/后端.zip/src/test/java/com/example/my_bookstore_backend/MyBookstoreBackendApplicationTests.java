package com.example.my_bookstore_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBookstoreBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
